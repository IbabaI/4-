create table if not exists product(
 p_id varchar(10) not null,
 p_name varchar(10),
 p_unitPrice Integer,
 p_description text,
 p_category varchar(20),
 p_manufacturer varchar(20),
 p_nuitsInStock long,
 p_condition varchar(20),
 p_fileName varchar(20),
 primary key(p_id) 


)default CHARSET=utf8;

select * from product;

select * from product where p_id;


drop table productsTop;

create table if not exists productsTop(
 p_id varchar(10) not null,
 p_name varchar(20),
 p_unitPrice Integer,
 p_description text,
 p_category varchar(50),
 p_manufacturer varchar(100),
 p_nuitsInStock long,
 p_condition varchar(100),
 p_fileName varchar(20),
 primary key(p_id)


)default CHARSET=utf8;


drop table productsBottom;

create table if not exists productsBottom(
 p_id varchar(10) not null,
 p_name varchar(20),
 p_unitPrice Integer,
 p_description text,
 p_category varchar(50),
 p_manufacturer varchar(100),
 p_nuitsInStock long,
 p_condition varchar(100),
 p_fileName varchar(20),
 primary key(p_id)


)default CHARSET=utf8;

drop table productsOutter;

create table if not exists productsOuter(
 p_id varchar(10) not null,
 p_name varchar(20),
 p_unitPrice Integer,
 p_description text,
 p_category varchar(50),
 p_manufacturer varchar(100),
 p_nuitsInStock long,
 p_condition varchar(100),
 p_fileName varchar(20),
 primary key(p_id)


)default CHARSET=utf8;

drop table productsShoes;

create table if not exists productsShoes(
 p_id varchar(10) not null,
 p_name varchar(20),
 p_unitPrice Integer,
 p_description text,
 p_category varchar(50),
 p_manufacturer varchar(100),
 p_nuitsInStock long,
 p_condition varchar(100),
 p_fileName varchar(20),
 primary key(p_id)


)default CHARSET=utf8;
