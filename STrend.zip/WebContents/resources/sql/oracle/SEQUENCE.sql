select * from board;

select * from user_objects where object_type='SEQUENCE';

create sequence board_seq start with 1 increment by 1;

select * from board;





