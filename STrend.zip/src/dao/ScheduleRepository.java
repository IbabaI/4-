package dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import dto.Schedule;

public class ScheduleRepository {
 List<Schedule> scheduleList = new ArrayList<>();

public ScheduleRepository(List<Schedule> scheduleList) {
	super();
	this.scheduleList = scheduleList;
}
public Schedule getSchedule(Date date, int seq){
	for(Schedule schedule: scheduleList) {
		 if(schedule.getSeq()==seq)
		 return schedule;	 
	}
	return null;
}
}