package dao;

import java.util.ArrayList;

import dto.Product;
//싱글톤으로 생성
public class ProductRepository {
	 //자신타입의 private static 필드 선언 
	 private static ProductRepository instance=new ProductRepository();
	 //public 접근지정자를 가진 getInstance메소드 선언
	public static ProductRepository getInstance() {
		return instance;
	}
	//필드
	 private ArrayList<Product> listOfProducts = new ArrayList<>();
	//생성자 private
	public ProductRepository() {
		Product TOP = new Product("P111-04", "top with a bardot neckline", 20000);
		TOP.setDescription("Colour: black, Outer 50% viscose 28% polyester 22% polyamide");
		TOP.setCategory("TOP");
		TOP.setManufacturer("bershka");
		TOP.setUnitsInStock(1000);
		TOP.setCondition("New");
		TOP.setFilename("Top01_Brown.jpg");
		
		 new Product("P111-02",  "high neck T-shirt", 25000);
		TOP.setDescription("Colour: white, Outer 50% viscose 28% polyester 22% polyamide");
		TOP.setCategory("TOP");
		TOP.setManufacturer("bershka");
		TOP.setUnitsInStock(1000);
		TOP.setCondition("New");
		TOP.setFilename("Top01_White.jpg");

		 new Product("P111-03", "top with a bardot neckline", 20000);
		TOP.setDescription("Colour: black, Outer 50% viscose 28% polyester 22% polyamide");
		TOP.setCategory("TOP");
		TOP.setManufacturer("bershka");
		TOP.setUnitsInStock(1000);
		TOP.setCondition("New");
		TOP.setFilename("Top01_Pink.jpg");
		
		listOfProducts.add(TOP); 
		listOfProducts.add(TOP); 
		listOfProducts.add(TOP);
	}

	//상품 리스트 출력 메소드
	public ArrayList<Product> getAllProducts(){
		return listOfProducts;
	} 

	//상품 id로 상품 상제 정보 얻기
	 public Product getProductById(String productId) {
		 Product productById = null;
	    for(int i=0;i<listOfProducts.size();i++) {
	    	 Product product = listOfProducts.get(i);
	    	 if(product !=null && product.getProductId()!=null 
	    			 && product.getProductId().equals(productId)) {
	    		 productById = product;
	    		 break;
	    	  }
	    	 }
		return  productById;
	 }//

	 //상품등록
	 public void addProduct(Product product) {
		 listOfProducts.add(product);
	 }
	}